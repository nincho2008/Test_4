import com.codeborne.selenide.Selenide;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.testng.Assert;
import org.testng.annotations.Test;

import static com.codeborne.selenide.Selectors.*;
import static com.codeborne.selenide.Selenide.*;

public class NegativCase {
    @Test(priority = 2)
    public void LogInWithInInvalidData() {
        WebDriverManager.chromedriver().setup();
        Selenide.open("https://auth.tnet.ge/ka/user/login/?Continue=https://myhome.ge/ka");

        $(byAttribute("type", "text")).setValue("nina.mamajanovi@gmail.com");
        $(byId("Password")).setValue("Alex1987");
        $(byText("შესვლა")).click();


        sleep(5000);



    }
    }


