import com.codeborne.selenide.Selenide;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.testng.annotations.Test;

import static com.codeborne.selenide.Selectors.*;
import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.*;

public class PozitivCase {

        @Test(priority = 1)
        public void LogInWithIncorrectData() {
            WebDriverManager.chromedriver().setup();
            Selenide.open("https://auth.tnet.ge/ka/user/login/?Continue=https://myhome.ge/ka");

            $(byAttribute("type", "text")).setValue("nina.mamajanovi@gmail.com");
            $(byId("Password")).setValue("Alex.1987");
            $(byText("შესვლა")).click();

            sleep(10000);


                }
            }


