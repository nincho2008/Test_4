import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chromium.ChromiumDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static com.codeborne.selenide.Selectors.byAttribute;
import static com.codeborne.selenide.Selenide.$;

public class BrowserAction {
    static WebDriver driver;
    private Object NegativCase;

    @BeforeMethod
     public void openBrowser() {
        ChromeDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://auth.tnet.ge/ka/user/login/?Continue=https://myhome.ge/ka");
    }

    @Test(priority = 1)

    public void LogInWithIncorrectData() {
        System.out.println("PozitivCase");


    }

    @Test(priority = 2)
    public void LogInWithInInvalidData() {
        System.out.println("NegativCase");
        this.NegativCase.getClass();
        Assert.assertEquals("rgba (226, 35, 26, 1)",
                this.NegativCase.getClass());


    }



    @AfterMethod
    public static void closeBrowser() {
        WebDriver driver = null;
        driver.quit();
    }
}
